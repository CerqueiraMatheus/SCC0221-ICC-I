#ifndef _BITMAP_READER_H
#define _BITMAP_READER_H

#include "bitmap_helper.h"
#include "file_helper.h"

int readBitMap(char *imageName,
               BitMap **bitMap);

#endif